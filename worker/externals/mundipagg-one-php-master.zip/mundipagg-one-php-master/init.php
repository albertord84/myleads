<?php

require_once(dirname(__FILE__) . '/AutoLoader.php');

\gateway\AutoLoader::registerDirectory(dirname(__FILE__) . DIRECTORY_SEPARATOR . "lib");