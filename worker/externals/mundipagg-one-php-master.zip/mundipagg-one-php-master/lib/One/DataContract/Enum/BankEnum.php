<?php
/**
 * Created by PhpStorm.
 * User: Moreira
 * Date: 17/06/2015
 * Time: 16:22
 */

namespace Gateway\One\DataContract\Enum;


abstract class BankEnum
{
    const BANCO_DO_BRASIL = "001";
    const SANTANDER = "033";
    const BRADESCO = "237";
    const ITAU = "341";
    const HSBC = "399";
}