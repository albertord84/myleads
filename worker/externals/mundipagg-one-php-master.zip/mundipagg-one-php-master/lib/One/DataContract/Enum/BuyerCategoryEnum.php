<?php

namespace Gateway\One\DataContract\Enum;

abstract class BuyerCategoryEnum
{
    const NORMAL = 'Normal';
    const PLUS = 'Plus';
}