<?php

namespace Gateway\One\DataContract\Enum;

/**
 * Class CountryEnum
 * @package Gateway\One\DataContract\Enum
 */
abstract class CountryEnum
{
    /**
     *
     */
    const BRAZIL = 'Brazil';
    /**
     *
     */
    const USA = 'USA';
    /**
     *
     */
    const ARGENTINA = 'Argentina';
    /**
     *
     */
    const BOLIVIA = 'Bolivia';
    /**
     *
     */
    const CHILE = 'Chile';
    /**
     *
     */
    const COLOMBIA = 'Colombia';
    /**
     *
     */
    const URUGUAY = 'Uruguay';
    /**
     *
     */
    const MEXICO = 'Mexico';
    /**
     *
     */
    const PARAGUAY = 'Paraguay';
}