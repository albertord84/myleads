<?php
/**
 * Created by PhpStorm.
 * User: Moreira
 * Date: 17/06/2015
 * Time: 14:15
 */

namespace Gateway\One\DataContract\Enum;


abstract class CurrencyIsoEnum
{
    const BRL = 'BRL';
    const EUR = 'EUR';
    const USD = 'USD';
    const ARS = 'ARS';
    const BOB = 'BOB';
    const CLP = 'CLP';
    const COP = 'COP';
    const UYU = 'UYU';
    const MXN = 'MXN';
    const PYG = 'PYG';
}