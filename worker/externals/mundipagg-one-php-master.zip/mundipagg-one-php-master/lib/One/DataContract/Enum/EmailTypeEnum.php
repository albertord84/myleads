<?php

namespace Gateway\One\DataContract\Enum;

abstract class EmailTypeEnum
{
    const COMERCIAL = 'Comercial';
    const PERSONAL = 'Personal';
}