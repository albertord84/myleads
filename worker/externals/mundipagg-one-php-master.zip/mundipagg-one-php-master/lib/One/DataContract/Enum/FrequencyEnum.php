<?php

namespace Gateway\One\DataContract\Enum;


abstract class FrequencyEnum
{
    const DAILY = 'Daily';
    const WEEKLY = 'Weekly';
    const MONTHLY = 'Monthly';
    const YEARLY = 'Yearly';
}