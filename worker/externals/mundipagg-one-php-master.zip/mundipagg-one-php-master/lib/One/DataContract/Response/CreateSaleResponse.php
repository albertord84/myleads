<?php

namespace Gateway\One\DataContract\Response;

class CreateSaleResponse
{
}